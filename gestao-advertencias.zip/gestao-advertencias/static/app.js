(function () {
  'use strict';
  var body = document.body;

  // Menu lateral (mobile)
  document.querySelectorAll('[data-toggle-sidebar]').forEach(function (b) {
    b.addEventListener('click', function () { body.classList.toggle('sidebar-open'); });
  });
  document.querySelectorAll('[data-close-sidebar]').forEach(function (b) {
    b.addEventListener('click', function () { body.classList.remove('sidebar-open'); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') body.classList.remove('sidebar-open');
  });

  // Larguras das barras (definidas via CSSOM por causa da CSP)
  requestAnimationFrame(function () {
    document.querySelectorAll('[data-w]').forEach(function (el) {
      el.style.width = Math.max(0, Math.min(100, parseInt(el.dataset.w, 10) || 0)) + '%';
    });
  });

  // Janelas de diálogo
  document.querySelectorAll('[data-open]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var d = document.getElementById(btn.dataset.open);
      if (d && d.showModal) { d.showModal(); var f = d.querySelector('textarea, input:not([type=hidden])'); if (f) f.focus(); }
    });
  });
  document.querySelectorAll('dialog [data-close]').forEach(function (btn) {
    btn.addEventListener('click', function () { btn.closest('dialog').close(); });
  });
  document.querySelectorAll('dialog').forEach(function (d) {
    d.addEventListener('click', function (e) { if (e.target === d) d.close(); });
  });

  // Confirmação antes de ações destrutivas
  var dialog = document.getElementById('confirm-dialog');
  if (dialog && dialog.showModal) {
    var pending = null;
    var okBtn = document.getElementById('confirm-ok');
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        if (form.dataset.confirmed === '1') { delete form.dataset.confirmed; return; }
        e.preventDefault();
        pending = form;
        document.getElementById('confirm-title').textContent = form.dataset.confirmTitle || 'Confirmar ação';
        document.getElementById('confirm-text').textContent = form.dataset.confirm;
        okBtn.textContent = form.dataset.confirmLabel || 'Confirmar';
        okBtn.className = 'btn ' + (form.dataset.confirmTone === 'primary' ? 'btn-primary' : 'btn-danger');
        dialog.showModal();
      });
    });
    dialog.addEventListener('close', function () {
      if (dialog.returnValue === 'ok' && pending) {
        var f = pending; pending = null;
        f.dataset.confirmed = '1';
        f.requestSubmit();
      } else { pending = null; }
      dialog.returnValue = '';
    });
  }

  // Evita envio duplicado
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (e.defaultPrevented || form.method.toLowerCase() !== 'post') return;
      setTimeout(function () {
        form.querySelectorAll('button[type=submit]').forEach(function (b) { b.disabled = true; });
      }, 0);
    });
  });
})();
