# -*- coding: utf-8 -*-
"""Sistema de Gerenciamento de Advertências (Flask + SQLite)."""
import csv
import hmac
import io
import json
import os
import re
import secrets
import sqlite3
import unicodedata
from datetime import datetime, timedelta, timezone
from functools import wraps
from urllib.parse import urlencode, urlparse

import click
from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from markupsafe import Markup, escape
from werkzeug.security import check_password_hash, generate_password_hash

# --------------------------------------------------------------------------
# Configuração
# --------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATA_DIR = os.environ.get("ADVERT_DATA_DIR", os.path.join(BASE_DIR, "data"))
DB_PATH = os.path.join(DATA_DIR, "advertencias.db")

CATEGORIAS = [
    "Conduta",
    "Atraso",
    "Falta",
    "Desempenho",
    "Segurança",
    "Descumprimento de normas",
    "Outra",
]
STATUS = {"ativa": "Ativa", "revisada": "Revisada", "cancelada": "Cancelada"}
STATUS_EDITAVEIS = ("ativa", "revisada")
PAPEIS = {"administrador": "Administrador", "visualizador": "Visualizador"}

MAX_TENTATIVAS = 5
BLOQUEIO_MINUTOS = 5
POR_PAGINA = 15
POR_PAGINA_AUDITORIA = 25

try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo(os.environ.get("APP_TZ", "America/Sao_Paulo"))
except Exception:  # pragma: no cover - sistema sem base de fusos
    TZ = timezone(timedelta(hours=-3))


def agora():
    return datetime.now(TZ).replace(tzinfo=None, microsecond=0)


def agora_iso():
    return agora().strftime("%Y-%m-%d %H:%M:%S")


def carregar_secret():
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    os.makedirs(DATA_DIR, exist_ok=True)
    caminho = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(caminho):
        try:
            fd = os.open(caminho, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(secrets.token_hex(32))
        except FileExistsError:
            pass
    with open(caminho, "r") as f:
        return f.read().strip()


app = Flask(__name__)
app.config.update(
    SECRET_KEY=carregar_secret(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("ADVERT_HTTPS") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=1024 * 1024,
    JSON_AS_ASCII=False,
)

# --------------------------------------------------------------------------
# Banco de dados
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    usuario TEXT NOT NULL UNIQUE COLLATE NOCASE,
    senha_hash TEXT NOT NULL,
    papel TEXT NOT NULL CHECK (papel IN ('administrador', 'visualizador')),
    ativo INTEGER NOT NULL DEFAULT 1,
    tentativas_falhas INTEGER NOT NULL DEFAULT 0,
    bloqueado_ate TEXT,
    criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pessoas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    funcao TEXT NOT NULL DEFAULT '',
    observacoes TEXT NOT NULL DEFAULT '',
    criado_em TEXT NOT NULL,
    atualizado_em TEXT NOT NULL,
    criado_por INTEGER REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS advertencias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pessoa_id INTEGER NOT NULL REFERENCES pessoas(id) ON DELETE CASCADE,
    titulo TEXT NOT NULL,
    motivo TEXT NOT NULL,
    categoria TEXT NOT NULL,
    ocorrido_em TEXT NOT NULL,
    responsavel TEXT NOT NULL,
    observacoes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'ativa'
        CHECK (status IN ('ativa', 'revisada', 'cancelada')),
    motivo_cancelamento TEXT,
    cancelado_em TEXT,
    cancelado_por TEXT,
    criado_em TEXT NOT NULL,
    atualizado_em TEXT NOT NULL,
    criado_por INTEGER REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS historico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entidade TEXT NOT NULL,
    entidade_id INTEGER,
    acao TEXT NOT NULL,
    usuario_id INTEGER,
    usuario_nome TEXT NOT NULL,
    descricao TEXT NOT NULL,
    detalhes TEXT,
    criado_em TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_adv_pessoa ON advertencias(pessoa_id);
CREATE INDEX IF NOT EXISTS idx_adv_ocorrido ON advertencias(ocorrido_em);
CREATE INDEX IF NOT EXISTS idx_adv_status ON advertencias(status);
CREATE INDEX IF NOT EXISTS idx_adv_categoria ON advertencias(categoria);
CREATE INDEX IF NOT EXISTS idx_hist_entidade ON historico(entidade, entidade_id);
CREATE INDEX IF NOT EXISTS idx_hist_criado ON historico(criado_em);
"""


def norm(valor):
    """Minúsculas e sem acentos, para buscas tolerantes."""
    if valor is None:
        return ""
    texto = unicodedata.normalize("NFKD", str(valor))
    return "".join(c for c in texto if not unicodedata.combining(c)).casefold()


def conectar():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.create_function("norm", 1, norm)
    return conn


def get_db():
    if "db" not in g:
        g.db = conectar()
    return g.db


@app.teardown_appcontext
def fechar_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = conectar()
    try:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


init_db()

DUMMY_HASH = generate_password_hash(secrets.token_hex(8))


# --------------------------------------------------------------------------
# Auditoria
# --------------------------------------------------------------------------
def registrar_historico(entidade, entidade_id, acao, descricao, detalhes=None):
    db = get_db()
    usuario = g.get("user")
    db.execute(
        "INSERT INTO historico (entidade, entidade_id, acao, usuario_id, "
        "usuario_nome, descricao, detalhes, criado_em) VALUES (?,?,?,?,?,?,?,?)",
        (
            entidade,
            entidade_id,
            acao,
            usuario["id"] if usuario else None,
            usuario["nome"] if usuario else "Sistema",
            descricao,
            json.dumps(detalhes, ensure_ascii=False) if detalhes else None,
            agora_iso(),
        ),
    )


def diferencas(antes, depois, campos):
    mudancas = {}
    for campo, rotulo in campos.items():
        a, d = antes.get(campo), depois.get(campo)
        if (a or "") != (d or ""):
            mudancas[rotulo] = {"de": a, "para": d}
    return mudancas


# --------------------------------------------------------------------------
# Utilidades de template
# --------------------------------------------------------------------------
ICONES = {
    "home": '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    "users": '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "user": '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    "alert": '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "plus": '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    "edit": '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    "trash": '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    "eye": '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    "search": '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    "ban": '<circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>',
    "clock": '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    "shield": '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    "logout": '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    "menu": '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    "check": '<polyline points="20 6 9 17 4 12"/>',
    "key": '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    "x": '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    "rotate": '<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>',
    "file": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    "back": '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
    "info": '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
}


def icon(nome, extra=""):
    interno = ICONES.get(nome, "")
    return Markup(
        '<svg class="icon %s" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '
        'aria-hidden="true">%s</svg>' % (escape(extra), interno)
    )


def status_badge(status):
    return Markup(
        '<span class="badge badge-%s">%s</span>'
        % (escape(status), escape(STATUS.get(status, status)))
    )


def fmt_dt(valor):
    if not valor:
        return ""
    for formato, saida in (
        ("%Y-%m-%dT%H:%M", "%d/%m/%Y %H:%M"),
        ("%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M"),
        ("%Y-%m-%dT%H:%M:%S", "%d/%m/%Y %H:%M"),
        ("%Y-%m-%d", "%d/%m/%Y"),
    ):
        try:
            return datetime.strptime(valor, formato).strftime(saida)
        except ValueError:
            continue
    return valor


def iniciais(nome):
    partes = [p for p in (nome or "").split() if p]
    if not partes:
        return "?"
    if len(partes) == 1:
        return partes[0][:2].upper()
    return (partes[0][0] + partes[-1][0]).upper()


def url_with(**kwargs):
    args = request.args.to_dict(flat=True)
    for chave, valor in kwargs.items():
        if valor in (None, ""):
            args.pop(chave, None)
        else:
            args[chave] = valor
    return request.path + ("?" + urlencode(args) if args else "")


app.jinja_env.globals.update(icon=icon, status_badge=status_badge, url_with=url_with)
app.jinja_env.filters["dt"] = fmt_dt
app.jinja_env.filters["iniciais"] = iniciais
app.jinja_env.filters["from_json"] = lambda s: json.loads(s) if s else None


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.context_processor
def contexto():
    user = g.get("user")
    return {
        "user": user,
        "is_admin": bool(user and user["papel"] == "administrador"),
        "CATEGORIAS": CATEGORIAS,
        "STATUS": STATUS,
        "STATUS_EDITAVEIS": STATUS_EDITAVEIS,
        "PAPEIS": PAPEIS,
    }


# --------------------------------------------------------------------------
# Segurança: CSRF, sessão, permissões
# --------------------------------------------------------------------------
ENDPOINTS_PUBLICOS = {"login", "setup", "static"}


def hash_sessao(senha_hash):
    return senha_hash[-16:]


@app.before_request
def antes_da_requisicao():
    g.user = None
    if request.method == "POST":
        enviado = request.form.get("_csrf", "")
        esperado = session.get("_csrf", "")
        if not enviado or not esperado or not hmac.compare_digest(enviado, esperado):
            abort(400, "Sessão expirada ou formulário inválido. Recarregue a página e tente novamente.")

    endpoint = request.endpoint
    if endpoint is None or endpoint == "static":
        return None

    db = get_db()
    uid = session.get("uid")
    if uid:
        linha = db.execute("SELECT * FROM usuarios WHERE id = ?", (uid,)).fetchone()
        if linha and linha["ativo"] and session.get("pv") == hash_sessao(linha["senha_hash"]):
            g.user = linha
        else:
            session.pop("uid", None)
            session.pop("pv", None)

    existe_usuario = db.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone()
    if not existe_usuario:
        if endpoint != "setup":
            return redirect(url_for("setup"))
        return None
    if endpoint == "setup":
        return redirect(url_for("login"))
    if endpoint in ENDPOINTS_PUBLICOS:
        return None
    if g.user is None:
        destino = request.full_path.rstrip("?") if request.method == "GET" else None
        return redirect(url_for("login", next=destino) if destino else url_for("login"))
    return None


@app.after_request
def cabecalhos(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self'; "
        "script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    )
    if request.endpoint != "static":
        resp.headers["Cache-Control"] = "no-store"
    return resp


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if g.user is None or g.user["papel"] != "administrador":
            abort(403)
        return view(*args, **kwargs)
    return wrapper


def proximo_seguro(destino):
    if not destino:
        return None
    analise = urlparse(destino)
    if analise.scheme or analise.netloc or not destino.startswith("/") or destino.startswith("//"):
        return None
    return destino


def iniciar_sessao(usuario):
    session.clear()
    session["uid"] = usuario["id"]
    session["pv"] = hash_sessao(usuario["senha_hash"])
    session.permanent = True


@app.errorhandler(400)
def erro_400(e):
    return render_template("erro.html", codigo=400, titulo="Requisição inválida",
                           mensagem=getattr(e, "description", "")), 400


@app.errorhandler(403)
def erro_403(_e):
    return render_template("erro.html", codigo=403, titulo="Acesso negado",
                           mensagem="Você não tem permissão para realizar esta ação."), 403


@app.errorhandler(404)
def erro_404(_e):
    return render_template("erro.html", codigo=404, titulo="Página não encontrada",
                           mensagem="O endereço acessado não existe ou o registro foi removido."), 404


@app.errorhandler(413)
def erro_413(_e):
    return render_template("erro.html", codigo=413, titulo="Conteúdo muito grande",
                           mensagem="O formulário enviado excede o tamanho permitido."), 413


@app.errorhandler(500)
def erro_500(_e):
    return render_template("erro.html", codigo=500, titulo="Erro interno",
                           mensagem="Algo deu errado. Tente novamente em instantes."), 500


# --------------------------------------------------------------------------
# Validação
# --------------------------------------------------------------------------
def espacos(valor):
    return " ".join((valor or "").split())


def validar_senha(senha, usuario=""):
    if len(senha) < 8:
        return "A senha deve ter pelo menos 8 caracteres."
    if len(senha) > 128:
        return "A senha deve ter no máximo 128 caracteres."
    if usuario and senha.casefold() == usuario.casefold():
        return "A senha não pode ser igual ao nome de usuário."
    return None


def validar_pessoa(form):
    dados = {
        "nome": espacos(form.get("nome")),
        "funcao": espacos(form.get("funcao")),
        "observacoes": (form.get("observacoes") or "").strip(),
    }
    erros = {}
    if not dados["nome"]:
        erros["nome"] = "Informe o nome completo."
    elif len(dados["nome"]) > 150:
        erros["nome"] = "Use no máximo 150 caracteres."
    if not dados["funcao"]:
        erros["funcao"] = "Informe a função."
    elif len(dados["funcao"]) > 100:
        erros["funcao"] = "Use no máximo 100 caracteres."
    if len(dados["observacoes"]) > 2000:
        erros["observacoes"] = "Use no máximo 2000 caracteres."
    return dados, erros


def parse_datahora(valor):
    valor = (valor or "").strip().replace(" ", "T")
    for formato in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(valor, formato)
        except ValueError:
            continue
    return None


def validar_advertencia(form, db):
    dados = {
        "pessoa_id": form.get("pessoa_id", ""),
        "titulo": espacos(form.get("titulo")),
        "motivo": (form.get("motivo") or "").strip(),
        "categoria": form.get("categoria", ""),
        "ocorrido_em": (form.get("ocorrido_em") or "").strip(),
        "responsavel": espacos(form.get("responsavel")),
        "observacoes": (form.get("observacoes") or "").strip(),
        "status": form.get("status", "ativa"),
    }
    erros = {}
    pessoa = None
    try:
        pessoa = db.execute("SELECT id, nome FROM pessoas WHERE id = ?",
                            (int(dados["pessoa_id"]),)).fetchone()
    except (TypeError, ValueError):
        pass
    if pessoa is None:
        erros["pessoa_id"] = "Selecione uma pessoa cadastrada."
    else:
        dados["pessoa_id"] = pessoa["id"]
    if not dados["titulo"]:
        erros["titulo"] = "Informe o título."
    elif len(dados["titulo"]) > 150:
        erros["titulo"] = "Use no máximo 150 caracteres."
    if not dados["motivo"]:
        erros["motivo"] = "Descreva o motivo da advertência."
    elif len(dados["motivo"]) > 5000:
        erros["motivo"] = "Use no máximo 5000 caracteres."
    if dados["categoria"] not in CATEGORIAS:
        erros["categoria"] = "Selecione uma categoria."
    data = parse_datahora(dados["ocorrido_em"])
    if data is None:
        erros["ocorrido_em"] = "Informe uma data e horário válidos."
    else:
        dados["ocorrido_em"] = data.strftime("%Y-%m-%dT%H:%M")
    if not dados["responsavel"]:
        erros["responsavel"] = "Informe o responsável pelo registro."
    elif len(dados["responsavel"]) > 120:
        erros["responsavel"] = "Use no máximo 120 caracteres."
    if len(dados["observacoes"]) > 2000:
        erros["observacoes"] = "Use no máximo 2000 caracteres."
    if dados["status"] not in STATUS_EDITAVEIS:
        erros["status"] = "Status inválido."
    return dados, erros, pessoa


# --------------------------------------------------------------------------
# Consultas auxiliares
# --------------------------------------------------------------------------
def like_pattern(texto):
    t = norm(texto).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return "%" + t + "%"


def paginar(total, pagina, por_pagina):
    paginas = max(1, -(-total // por_pagina))
    pagina = min(max(pagina, 1), paginas)
    return {"page": pagina, "pages": paginas, "per": por_pagina,
            "total": total, "offset": (pagina - 1) * por_pagina}


DATA_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def data_valida(valor):
    if not valor or not DATA_RE.match(valor):
        return None
    try:
        datetime.strptime(valor, "%Y-%m-%d")
        return valor
    except ValueError:
        return None


def filtros_advertencias(args):
    where, params = [], []
    filtros = {
        "q": (args.get("q") or "").strip(),
        "pessoa": args.get("pessoa", type=int),
        "categoria": args.get("categoria", ""),
        "status": args.get("status", ""),
        "de": data_valida(args.get("de", "")),
        "ate": data_valida(args.get("ate", "")),
    }
    if filtros["q"]:
        like = like_pattern(filtros["q"])
        where.append("(norm(a.titulo) LIKE ? ESCAPE '\\' OR norm(a.motivo) LIKE ? ESCAPE '\\')")
        params += [like, like]
    if filtros["pessoa"]:
        where.append("a.pessoa_id = ?")
        params.append(filtros["pessoa"])
    if filtros["categoria"] in CATEGORIAS:
        where.append("a.categoria = ?")
        params.append(filtros["categoria"])
    else:
        filtros["categoria"] = ""
    if filtros["status"] in STATUS:
        where.append("a.status = ?")
        params.append(filtros["status"])
    else:
        filtros["status"] = ""
    if filtros["de"]:
        where.append("substr(a.ocorrido_em, 1, 10) >= ?")
        params.append(filtros["de"])
    if filtros["ate"]:
        where.append("substr(a.ocorrido_em, 1, 10) <= ?")
        params.append(filtros["ate"])
    clausula = (" WHERE " + " AND ".join(where)) if where else ""
    return clausula, params, filtros


def buscar_advertencia(db, adv_id):
    linha = db.execute(
        "SELECT a.*, p.nome AS pessoa_nome, p.funcao AS pessoa_funcao, "
        "u.nome AS criado_por_nome FROM advertencias a "
        "JOIN pessoas p ON p.id = a.pessoa_id "
        "LEFT JOIN usuarios u ON u.id = a.criado_por WHERE a.id = ?",
        (adv_id,),
    ).fetchone()
    if linha is None:
        abort(404)
    return linha


def buscar_pessoa(db, pessoa_id):
    linha = db.execute("SELECT * FROM pessoas WHERE id = ?", (pessoa_id,)).fetchone()
    if linha is None:
        abort(404)
    return linha


# --------------------------------------------------------------------------
# Autenticação
# --------------------------------------------------------------------------
@app.route("/setup", methods=["GET", "POST"])
def setup():
    db = get_db()
    erros, v = {}, {"nome": "", "usuario": ""}
    if request.method == "POST":
        v = {"nome": espacos(request.form.get("nome")),
             "usuario": (request.form.get("usuario") or "").strip()}
        senha = request.form.get("senha", "")
        confirmar = request.form.get("confirmar", "")
        if not v["nome"]:
            erros["nome"] = "Informe seu nome."
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", v["usuario"]):
            erros["usuario"] = "Use de 3 a 40 caracteres: letras, números, ponto, hífen ou sublinhado."
        msg = validar_senha(senha, v["usuario"])
        if msg:
            erros["senha"] = msg
        elif senha != confirmar:
            erros["confirmar"] = "As senhas não conferem."
        if not erros:
            cur = db.execute(
                "INSERT INTO usuarios (nome, usuario, senha_hash, papel, criado_em) "
                "VALUES (?,?,?,?,?)",
                (v["nome"], v["usuario"], generate_password_hash(senha),
                 "administrador", agora_iso()),
            )
            db.commit()
            novo = db.execute("SELECT * FROM usuarios WHERE id = ?", (cur.lastrowid,)).fetchone()
            g.user = novo
            registrar_historico("usuario", novo["id"], "criou",
                                'Administrador inicial "%s" criado' % novo["usuario"])
            db.commit()
            iniciar_sessao(novo)
            flash("Conta de administrador criada. Bem-vindo(a)!", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", modo="setup", erros=erros, v=v), (400 if erros else 200)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard"))
    erro = None
    usuario_digitado = ""
    if request.method == "POST":
        db = get_db()
        usuario_digitado = (request.form.get("usuario") or "").strip()
        senha = request.form.get("senha", "")
        linha = db.execute("SELECT * FROM usuarios WHERE usuario = ?", (usuario_digitado,)).fetchone()
        if linha and linha["bloqueado_ate"] and datetime.fromisoformat(linha["bloqueado_ate"]) > agora():
            erro = "Muitas tentativas incorretas. Aguarde alguns minutos e tente novamente."
        elif linha and linha["ativo"] and check_password_hash(linha["senha_hash"], senha):
            db.execute("UPDATE usuarios SET tentativas_falhas = 0, bloqueado_ate = NULL WHERE id = ?",
                       (linha["id"],))
            db.commit()
            proximo = proximo_seguro(request.args.get("next") or request.form.get("next"))
            iniciar_sessao(linha)
            return redirect(proximo or url_for("dashboard"))
        else:
            if linha:
                tentativas = linha["tentativas_falhas"] + 1
                bloqueio = None
                if tentativas >= MAX_TENTATIVAS:
                    bloqueio = (agora() + timedelta(minutes=BLOQUEIO_MINUTOS)).isoformat()
                    tentativas = 0
                db.execute("UPDATE usuarios SET tentativas_falhas = ?, bloqueado_ate = ? WHERE id = ?",
                           (tentativas, bloqueio, linha["id"]))
                db.commit()
            else:
                check_password_hash(DUMMY_HASH, senha)
            erro = "Usuário ou senha inválidos."
    return render_template("auth.html", modo="login", erro=erro, v={"usuario": usuario_digitado},
                           erros={}, next=request.args.get("next", "")), (401 if erro else 200)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Você saiu do sistema.", "info")
    return redirect(url_for("login"))


@app.route("/conta/senha", methods=["GET", "POST"])
def conta_senha():
    erros = {}
    if request.method == "POST":
        atual = request.form.get("atual", "")
        nova = request.form.get("nova", "")
        confirmar = request.form.get("confirmar", "")
        if not check_password_hash(g.user["senha_hash"], atual):
            erros["atual"] = "Senha atual incorreta."
        msg = validar_senha(nova, g.user["usuario"])
        if msg:
            erros["nova"] = msg
        elif nova != confirmar:
            erros["confirmar"] = "As senhas não conferem."
        if not erros:
            db = get_db()
            novo_hash = generate_password_hash(nova)
            db.execute("UPDATE usuarios SET senha_hash = ? WHERE id = ?", (novo_hash, g.user["id"]))
            registrar_historico("usuario", g.user["id"], "editou", "Senha alterada pelo próprio usuário")
            db.commit()
            session["pv"] = hash_sessao(novo_hash)
            flash("Senha alterada com sucesso.", "success")
            return redirect(url_for("dashboard"))
    return render_template("conta_senha.html", erros=erros), (400 if erros else 200)


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------
@app.route("/")
def dashboard():
    db = get_db()
    total_pessoas = db.execute("SELECT COUNT(*) FROM pessoas").fetchone()[0]
    por_status = {s: 0 for s in STATUS}
    for linha in db.execute("SELECT status, COUNT(*) n FROM advertencias GROUP BY status"):
        por_status[linha["status"]] = linha["n"]
    total_adv = sum(por_status.values())
    limite = (agora() - timedelta(days=30)).strftime("%Y-%m-%d")
    ultimos_30 = db.execute(
        "SELECT COUNT(*) FROM advertencias WHERE status != 'cancelada' "
        "AND substr(ocorrido_em, 1, 10) >= ?", (limite,)).fetchone()[0]
    ranking = db.execute(
        "SELECT p.id, p.nome, p.funcao, COUNT(a.id) AS total, "
        "COALESCE(SUM(a.status = 'ativa'), 0) AS ativas "
        "FROM pessoas p JOIN advertencias a ON a.pessoa_id = p.id AND a.status != 'cancelada' "
        "GROUP BY p.id ORDER BY total DESC, ativas DESC, norm(p.nome) LIMIT 5").fetchall()
    recentes = db.execute(
        "SELECT a.id, a.titulo, a.categoria, a.status, a.ocorrido_em, a.responsavel, "
        "p.id AS pessoa_id, p.nome AS pessoa_nome FROM advertencias a "
        "JOIN pessoas p ON p.id = a.pessoa_id ORDER BY a.id DESC LIMIT 8").fetchall()
    categorias = db.execute(
        "SELECT categoria, COUNT(*) n FROM advertencias WHERE status != 'cancelada' "
        "GROUP BY categoria ORDER BY n DESC").fetchall()
    return render_template(
        "dashboard.html", total_pessoas=total_pessoas, total_adv=total_adv,
        por_status=por_status, ultimos_30=ultimos_30, ranking=ranking,
        recentes=recentes, categorias=categorias,
        max_rank=(ranking[0]["total"] if ranking else 1),
        max_cat=(categorias[0]["n"] if categorias else 1))


# --------------------------------------------------------------------------
# Pessoas
# --------------------------------------------------------------------------
@app.route("/pessoas")
def pessoas_lista():
    db = get_db()
    q = (request.args.get("q") or "").strip()
    ordem = request.args.get("ordem", "nome")
    where, params = "", []
    if q:
        like = like_pattern(q)
        where = " WHERE (norm(p.nome) LIKE ? ESCAPE '\\' OR norm(p.funcao) LIKE ? ESCAPE '\\')"
        params = [like, like]
    total = db.execute("SELECT COUNT(*) FROM pessoas p" + where, params).fetchone()[0]
    pag = paginar(total, request.args.get("page", 1, type=int), POR_PAGINA)
    order_by = "total DESC, norm(p.nome)" if ordem == "advertencias" else "norm(p.nome)"
    itens = db.execute(
        "SELECT p.*, COUNT(a.id) AS total, "
        "COALESCE(SUM(a.status = 'ativa'), 0) AS ativas "
        "FROM pessoas p LEFT JOIN advertencias a ON a.pessoa_id = p.id" + where +
        " GROUP BY p.id ORDER BY " + order_by + " LIMIT ? OFFSET ?",
        params + [pag["per"], pag["offset"]]).fetchall()
    return render_template("pessoas.html", itens=itens, pag=pag, q=q, ordem=ordem)


@app.route("/pessoas/nova", methods=["GET", "POST"])
@admin_required
def pessoa_nova():
    erros, v = {}, {"nome": "", "funcao": "", "observacoes": ""}
    if request.method == "POST":
        v, erros = validar_pessoa(request.form)
        if not erros:
            db = get_db()
            agora_s = agora_iso()
            cur = db.execute(
                "INSERT INTO pessoas (nome, funcao, observacoes, criado_em, atualizado_em, criado_por) "
                "VALUES (?,?,?,?,?,?)",
                (v["nome"], v["funcao"], v["observacoes"], agora_s, agora_s, g.user["id"]))
            registrar_historico("pessoa", cur.lastrowid, "criou",
                                'Pessoa "%s" cadastrada' % v["nome"], v)
            db.commit()
            flash("Pessoa cadastrada com sucesso.", "success")
            return redirect(url_for("pessoa_detalhe", pessoa_id=cur.lastrowid))
    return render_template("pessoa_form.html", v=v, erros=erros, edicao=False), (400 if erros else 200)


@app.route("/pessoas/<int:pessoa_id>")
def pessoa_detalhe(pessoa_id):
    db = get_db()
    pessoa = buscar_pessoa(db, pessoa_id)
    adv = db.execute(
        "SELECT * FROM advertencias WHERE pessoa_id = ? ORDER BY ocorrido_em DESC, id DESC",
        (pessoa_id,)).fetchall()
    contagem = {s: 0 for s in STATUS}
    for a in adv:
        contagem[a["status"]] += 1
    return render_template("pessoa_detalhe.html", pessoa=pessoa, adv=adv, contagem=contagem)


@app.route("/pessoas/<int:pessoa_id>/editar", methods=["GET", "POST"])
@admin_required
def pessoa_editar(pessoa_id):
    db = get_db()
    pessoa = buscar_pessoa(db, pessoa_id)
    erros = {}
    v = {"nome": pessoa["nome"], "funcao": pessoa["funcao"], "observacoes": pessoa["observacoes"]}
    if request.method == "POST":
        v, erros = validar_pessoa(request.form)
        if not erros:
            mudancas = diferencas(
                dict(pessoa), v, {"nome": "Nome", "funcao": "Função", "observacoes": "Observações"})
            db.execute("UPDATE pessoas SET nome = ?, funcao = ?, observacoes = ?, atualizado_em = ? WHERE id = ?",
                       (v["nome"], v["funcao"], v["observacoes"], agora_iso(), pessoa_id))
            if mudancas:
                registrar_historico("pessoa", pessoa_id, "editou",
                                    'Dados de "%s" alterados' % v["nome"], mudancas)
            db.commit()
            flash("Cadastro atualizado.", "success")
            return redirect(url_for("pessoa_detalhe", pessoa_id=pessoa_id))
    return render_template("pessoa_form.html", v=v, erros=erros, edicao=True, pessoa=pessoa), (400 if erros else 200)


@app.route("/pessoas/<int:pessoa_id>/excluir", methods=["POST"])
@admin_required
def pessoa_excluir(pessoa_id):
    db = get_db()
    pessoa = buscar_pessoa(db, pessoa_id)
    adv = db.execute(
        "SELECT id, titulo, categoria, status, ocorrido_em, responsavel FROM advertencias "
        "WHERE pessoa_id = ? ORDER BY ocorrido_em", (pessoa_id,)).fetchall()
    detalhes = {
        "pessoa": {"nome": pessoa["nome"], "funcao": pessoa["funcao"],
                   "observacoes": pessoa["observacoes"]},
        "advertencias_removidas": [dict(a) for a in adv],
    }
    db.execute("DELETE FROM pessoas WHERE id = ?", (pessoa_id,))
    desc = 'Pessoa "%s" excluída' % pessoa["nome"]
    if adv:
        desc += " junto com %d advertência(s)" % len(adv)
    registrar_historico("pessoa", pessoa_id, "excluiu", desc, detalhes)
    db.commit()
    flash("Pessoa excluída. O registro da exclusão ficou na auditoria.", "success")
    return redirect(url_for("pessoas_lista"))


# --------------------------------------------------------------------------
# Advertências
# --------------------------------------------------------------------------
def lista_pessoas(db):
    return db.execute("SELECT id, nome, funcao FROM pessoas ORDER BY norm(nome)").fetchall()


@app.route("/advertencias")
def advertencias_lista():
    db = get_db()
    clausula, params, filtros = filtros_advertencias(request.args)
    total = db.execute("SELECT COUNT(*) FROM advertencias a" + clausula, params).fetchone()[0]
    pag = paginar(total, request.args.get("page", 1, type=int), POR_PAGINA)
    itens = db.execute(
        "SELECT a.id, a.titulo, a.categoria, a.status, a.ocorrido_em, a.responsavel, "
        "p.id AS pessoa_id, p.nome AS pessoa_nome FROM advertencias a "
        "JOIN pessoas p ON p.id = a.pessoa_id" + clausula +
        " ORDER BY a.ocorrido_em DESC, a.id DESC LIMIT ? OFFSET ?",
        params + [pag["per"], pag["offset"]]).fetchall()
    filtrado = any(filtros[k] for k in filtros)
    return render_template("advertencias.html", itens=itens, pag=pag, f=filtros,
                           pessoas=lista_pessoas(db), filtrado=filtrado)


def _csv_seguro(valor):
    texto = "" if valor is None else str(valor)
    if texto[:1] in ("=", "+", "-", "@", "\t", "\r"):
        texto = "'" + texto
    return texto


@app.route("/advertencias/exportar.csv")
def advertencias_exportar():
    db = get_db()
    clausula, params, _ = filtros_advertencias(request.args)
    linhas = db.execute(
        "SELECT a.id, p.nome AS pessoa, p.funcao, a.titulo, a.categoria, a.status, a.ocorrido_em, "
        "a.responsavel, a.motivo, a.observacoes, a.motivo_cancelamento FROM advertencias a "
        "JOIN pessoas p ON p.id = a.pessoa_id" + clausula +
        " ORDER BY a.ocorrido_em DESC, a.id DESC", params).fetchall()
    buf = io.StringIO()
    buf.write("﻿")
    w = csv.writer(buf, delimiter=";")
    w.writerow(["ID", "Pessoa", "Função", "Título", "Categoria", "Status", "Data e horário",
                "Responsável", "Motivo", "Observações", "Motivo do cancelamento"])
    for l in linhas:
        w.writerow([_csv_seguro(x) for x in (
            l["id"], l["pessoa"], l["funcao"], l["titulo"], l["categoria"],
            STATUS.get(l["status"], l["status"]), fmt_dt(l["ocorrido_em"]), l["responsavel"],
            l["motivo"], l["observacoes"], l["motivo_cancelamento"])])
    nome = "advertencias_%s.csv" % agora().strftime("%Y%m%d_%H%M")
    return Response(buf.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=%s" % nome})


@app.route("/advertencias/nova", methods=["GET", "POST"])
@admin_required
def advertencia_nova():
    db = get_db()
    pessoas = lista_pessoas(db)
    erros = {}
    v = {"pessoa_id": request.args.get("pessoa", ""), "titulo": "", "motivo": "",
         "categoria": "", "ocorrido_em": agora().strftime("%Y-%m-%dT%H:%M"),
         "responsavel": g.user["nome"], "observacoes": "", "status": "ativa"}
    if request.method == "POST":
        v, erros, pessoa = validar_advertencia(request.form, db)
        if not erros:
            agora_s = agora_iso()
            cur = db.execute(
                "INSERT INTO advertencias (pessoa_id, titulo, motivo, categoria, ocorrido_em, "
                "responsavel, observacoes, status, criado_em, atualizado_em, criado_por) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (v["pessoa_id"], v["titulo"], v["motivo"], v["categoria"], v["ocorrido_em"],
                 v["responsavel"], v["observacoes"], v["status"], agora_s, agora_s, g.user["id"]))
            detalhes = dict(v)
            detalhes["pessoa"] = pessoa["nome"]
            registrar_historico("advertencia", cur.lastrowid, "criou",
                                'Advertência "%s" registrada para %s' % (v["titulo"], pessoa["nome"]),
                                detalhes)
            db.commit()
            flash("Advertência registrada com sucesso.", "success")
            return redirect(url_for("advertencia_detalhe", adv_id=cur.lastrowid))
    return render_template("advertencia_form.html", v=v, erros=erros, pessoas=pessoas,
                           edicao=False), (400 if erros else 200)


@app.route("/advertencias/<int:adv_id>")
def advertencia_detalhe(adv_id):
    db = get_db()
    adv = buscar_advertencia(db, adv_id)
    historico = []
    if g.user["papel"] == "administrador":
        historico = db.execute(
            "SELECT * FROM historico WHERE entidade = 'advertencia' AND entidade_id = ? "
            "ORDER BY id DESC", (adv_id,)).fetchall()
    return render_template("advertencia_detalhe.html", adv=adv, historico=historico)


@app.route("/advertencias/<int:adv_id>/editar", methods=["GET", "POST"])
@admin_required
def advertencia_editar(adv_id):
    db = get_db()
    adv = buscar_advertencia(db, adv_id)
    if adv["status"] == "cancelada":
        flash("Esta advertência está cancelada. Reative-a antes de editar.", "error")
        return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    pessoas = lista_pessoas(db)
    erros = {}
    v = {k: adv[k] for k in ("pessoa_id", "titulo", "motivo", "categoria", "ocorrido_em",
                              "responsavel", "observacoes", "status")}
    if request.method == "POST":
        v, erros, pessoa = validar_advertencia(request.form, db)
        if not erros:
            antes = {k: adv[k] for k in v}
            antes["pessoa_id"] = adv["pessoa_nome"]
            depois = dict(v)
            depois["pessoa_id"] = pessoa["nome"]
            mudancas = diferencas(antes, depois, {
                "pessoa_id": "Pessoa", "titulo": "Título", "motivo": "Motivo",
                "categoria": "Categoria", "ocorrido_em": "Data e horário",
                "responsavel": "Responsável", "observacoes": "Observações", "status": "Status"})
            db.execute(
                "UPDATE advertencias SET pessoa_id = ?, titulo = ?, motivo = ?, categoria = ?, "
                "ocorrido_em = ?, responsavel = ?, observacoes = ?, status = ?, atualizado_em = ? "
                "WHERE id = ?",
                (v["pessoa_id"], v["titulo"], v["motivo"], v["categoria"], v["ocorrido_em"],
                 v["responsavel"], v["observacoes"], v["status"], agora_iso(), adv_id))
            if mudancas:
                registrar_historico("advertencia", adv_id, "editou",
                                    'Advertência "%s" editada' % v["titulo"], mudancas)
            db.commit()
            flash("Advertência atualizada.", "success")
            return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    return render_template("advertencia_form.html", v=v, erros=erros, pessoas=pessoas,
                           edicao=True, adv=adv), (400 if erros else 200)


@app.route("/advertencias/<int:adv_id>/cancelar", methods=["POST"])
@admin_required
def advertencia_cancelar(adv_id):
    db = get_db()
    adv = buscar_advertencia(db, adv_id)
    if adv["status"] == "cancelada":
        flash("Esta advertência já está cancelada.", "info")
        return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    motivo = (request.form.get("motivo_cancelamento") or "").strip()
    if not motivo:
        flash("Informe o motivo do cancelamento.", "error")
        return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    if len(motivo) > 2000:
        flash("O motivo do cancelamento deve ter no máximo 2000 caracteres.", "error")
        return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    db.execute(
        "UPDATE advertencias SET status = 'cancelada', motivo_cancelamento = ?, cancelado_em = ?, "
        "cancelado_por = ?, atualizado_em = ? WHERE id = ?",
        (motivo, agora_iso(), g.user["nome"], agora_iso(), adv_id))
    registrar_historico("advertencia", adv_id, "cancelou",
                        'Advertência "%s" de %s cancelada' % (adv["titulo"], adv["pessoa_nome"]),
                        {"Status": {"de": adv["status"], "para": "cancelada"},
                         "Motivo do cancelamento": {"de": None, "para": motivo}})
    db.commit()
    flash("Advertência cancelada. O registro foi mantido no histórico.", "success")
    return redirect(url_for("advertencia_detalhe", adv_id=adv_id))


@app.route("/advertencias/<int:adv_id>/reativar", methods=["POST"])
@admin_required
def advertencia_reativar(adv_id):
    db = get_db()
    adv = buscar_advertencia(db, adv_id)
    if adv["status"] != "cancelada":
        flash("Apenas advertências canceladas podem ser reativadas.", "info")
        return redirect(url_for("advertencia_detalhe", adv_id=adv_id))
    db.execute(
        "UPDATE advertencias SET status = 'ativa', motivo_cancelamento = NULL, cancelado_em = NULL, "
        "cancelado_por = NULL, atualizado_em = ? WHERE id = ?", (agora_iso(), adv_id))
    registrar_historico("advertencia", adv_id, "reativou",
                        'Advertência "%s" de %s reativada' % (adv["titulo"], adv["pessoa_nome"]),
                        {"Status": {"de": "cancelada", "para": "ativa"}})
    db.commit()
    flash("Advertência reativada.", "success")
    return redirect(url_for("advertencia_detalhe", adv_id=adv_id))


# --------------------------------------------------------------------------
# Usuários (somente administradores)
# --------------------------------------------------------------------------
USUARIO_RE = re.compile(r"[A-Za-z0-9_.-]{3,40}")


def admins_ativos(db):
    return db.execute(
        "SELECT COUNT(*) FROM usuarios WHERE papel = 'administrador' AND ativo = 1").fetchone()[0]


@app.route("/usuarios")
@admin_required
def usuarios_lista():
    itens = get_db().execute("SELECT * FROM usuarios ORDER BY norm(nome)").fetchall()
    return render_template("usuarios.html", itens=itens)


@app.route("/usuarios/novo", methods=["GET", "POST"])
@admin_required
def usuario_novo():
    db = get_db()
    erros, v = {}, {"nome": "", "usuario": "", "papel": "visualizador"}
    if request.method == "POST":
        v = {"nome": espacos(request.form.get("nome")),
             "usuario": (request.form.get("usuario") or "").strip(),
             "papel": request.form.get("papel", "")}
        senha = request.form.get("senha", "")
        if not v["nome"]:
            erros["nome"] = "Informe o nome."
        elif len(v["nome"]) > 120:
            erros["nome"] = "Use no máximo 120 caracteres."
        if not USUARIO_RE.fullmatch(v["usuario"]):
            erros["usuario"] = "Use de 3 a 40 caracteres: letras, números, ponto, hífen ou sublinhado."
        elif db.execute("SELECT 1 FROM usuarios WHERE usuario = ?", (v["usuario"],)).fetchone():
            erros["usuario"] = "Este nome de usuário já está em uso."
        if v["papel"] not in PAPEIS:
            erros["papel"] = "Selecione um nível de acesso."
        msg = validar_senha(senha, v["usuario"])
        if msg:
            erros["senha"] = msg
        if not erros:
            cur = db.execute(
                "INSERT INTO usuarios (nome, usuario, senha_hash, papel, criado_em) VALUES (?,?,?,?,?)",
                (v["nome"], v["usuario"], generate_password_hash(senha), v["papel"], agora_iso()))
            registrar_historico("usuario", cur.lastrowid, "criou",
                                'Usuário "%s" criado (%s)' % (v["usuario"], PAPEIS[v["papel"]]))
            db.commit()
            flash("Usuário criado.", "success")
            return redirect(url_for("usuarios_lista"))
    return render_template("usuario_form.html", v=v, erros=erros, edicao=False), (400 if erros else 200)


@app.route("/usuarios/<int:usuario_id>/editar", methods=["GET", "POST"])
@admin_required
def usuario_editar(usuario_id):
    db = get_db()
    alvo = db.execute("SELECT * FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
    if alvo is None:
        abort(404)
    erros = {}
    v = {"nome": alvo["nome"], "papel": alvo["papel"], "ativo": bool(alvo["ativo"])}
    if request.method == "POST":
        v = {"nome": espacos(request.form.get("nome")),
             "papel": request.form.get("papel", ""),
             "ativo": request.form.get("ativo") == "1"}
        senha = request.form.get("senha", "")
        if not v["nome"]:
            erros["nome"] = "Informe o nome."
        elif len(v["nome"]) > 120:
            erros["nome"] = "Use no máximo 120 caracteres."
        if v["papel"] not in PAPEIS:
            erros["papel"] = "Selecione um nível de acesso."
        if alvo["id"] == g.user["id"] and not v["ativo"]:
            erros["ativo"] = "Você não pode desativar a própria conta."
        if (alvo["papel"] == "administrador" and alvo["ativo"]
                and (v["papel"] != "administrador" or not v["ativo"])
                and admins_ativos(db) <= 1):
            erros["papel"] = "O sistema precisa de pelo menos um administrador ativo."
        if senha:
            msg = validar_senha(senha, alvo["usuario"])
            if msg:
                erros["senha"] = msg
        if not erros:
            mudancas = {}
            if v["nome"] != alvo["nome"]:
                mudancas["Nome"] = {"de": alvo["nome"], "para": v["nome"]}
            if v["papel"] != alvo["papel"]:
                mudancas["Nível de acesso"] = {"de": PAPEIS[alvo["papel"]], "para": PAPEIS[v["papel"]]}
            if v["ativo"] != bool(alvo["ativo"]):
                mudancas["Ativo"] = {"de": "sim" if alvo["ativo"] else "não",
                                     "para": "sim" if v["ativo"] else "não"}
            if senha:
                mudancas["Senha"] = {"de": None, "para": "redefinida por administrador"}
                db.execute("UPDATE usuarios SET senha_hash = ?, tentativas_falhas = 0, bloqueado_ate = NULL "
                           "WHERE id = ?", (generate_password_hash(senha), usuario_id))
            db.execute("UPDATE usuarios SET nome = ?, papel = ?, ativo = ? WHERE id = ?",
                       (v["nome"], v["papel"], 1 if v["ativo"] else 0, usuario_id))
            if mudancas:
                registrar_historico("usuario", usuario_id, "editou",
                                    'Usuário "%s" alterado' % alvo["usuario"], mudancas)
            db.commit()
            if alvo["id"] == g.user["id"] and senha:
                nova = db.execute("SELECT senha_hash FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
                session["pv"] = hash_sessao(nova["senha_hash"])
            flash("Usuário atualizado.", "success")
            return redirect(url_for("usuarios_lista"))
    return render_template("usuario_form.html", v=v, erros=erros, edicao=True, alvo=alvo), (400 if erros else 200)


# --------------------------------------------------------------------------
# Auditoria (somente administradores)
# --------------------------------------------------------------------------
@app.route("/auditoria")
@admin_required
def auditoria():
    db = get_db()
    entidade = request.args.get("entidade", "")
    acao = request.args.get("acao", "")
    q = (request.args.get("q") or "").strip()
    where, params = [], []
    if entidade in ("pessoa", "advertencia", "usuario"):
        where.append("entidade = ?")
        params.append(entidade)
    else:
        entidade = ""
    if acao in ("criou", "editou", "excluiu", "cancelou", "reativou"):
        where.append("acao = ?")
        params.append(acao)
    else:
        acao = ""
    if q:
        like = like_pattern(q)
        where.append("(norm(descricao) LIKE ? ESCAPE '\\' OR norm(usuario_nome) LIKE ? ESCAPE '\\')")
        params += [like, like]
    clausula = (" WHERE " + " AND ".join(where)) if where else ""
    total = db.execute("SELECT COUNT(*) FROM historico" + clausula, params).fetchone()[0]
    pag = paginar(total, request.args.get("page", 1, type=int), POR_PAGINA_AUDITORIA)
    itens = db.execute("SELECT * FROM historico" + clausula + " ORDER BY id DESC LIMIT ? OFFSET ?",
                       params + [pag["per"], pag["offset"]]).fetchall()
    return render_template("auditoria.html", itens=itens, pag=pag, entidade=entidade, acao=acao, q=q)


# --------------------------------------------------------------------------
# Linha de comando
# --------------------------------------------------------------------------
@app.cli.command("redefinir-senha")
@click.argument("usuario")
def cli_redefinir_senha(usuario):
    """Redefine a senha de um usuário (uso em caso de senha esquecida)."""
    conn = conectar()
    linha = conn.execute("SELECT id FROM usuarios WHERE usuario = ?", (usuario,)).fetchone()
    if linha is None:
        raise click.ClickException("Usuário não encontrado.")
    senha = click.prompt("Nova senha", hide_input=True, confirmation_prompt=True)
    msg = validar_senha(senha, usuario)
    if msg:
        raise click.ClickException(msg)
    conn.execute("UPDATE usuarios SET senha_hash = ?, tentativas_falhas = 0, bloqueado_ate = NULL, ativo = 1 "
                 "WHERE id = ?", (generate_password_hash(senha), linha["id"]))
    conn.execute("INSERT INTO historico (entidade, entidade_id, acao, usuario_nome, descricao, criado_em) "
                 "VALUES ('usuario', ?, 'editou', 'Sistema (linha de comando)', ?, ?)",
                 (linha["id"], 'Senha de "%s" redefinida pela linha de comando' % usuario, agora_iso()))
    conn.commit()
    conn.close()
    click.echo("Senha redefinida com sucesso.")


if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"),
            port=int(os.environ.get("PORT", "5000")), debug=False)
