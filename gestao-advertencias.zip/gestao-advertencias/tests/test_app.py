# -*- coding: utf-8 -*-
import os
import re
import sqlite3
import sys
import tempfile
import unittest

TMP = tempfile.mkdtemp(prefix="advert_test_")
os.environ["ADVERT_DATA_DIR"] = TMP
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as sistema  # noqa: E402

CSRF = re.compile(r'name="_csrf" value="([^"]+)"')


class Cliente:
    def __init__(self):
        self.c = sistema.app.test_client()

    def token(self, url="/login"):
        html = self.c.get(url, follow_redirects=True).get_data(as_text=True)
        m = CSRF.search(html)
        assert m, "token csrf não encontrado em " + url
        return m.group(1)

    def post(self, url, dados=None, token_url=None, follow=False, csrf=True):
        dados = dict(dados or {})
        if csrf:
            dados["_csrf"] = self.token(token_url or url)
        return self.c.post(url, data=dados, follow_redirects=follow)

    def get(self, url, **kw):
        return self.c.get(url, **kw)


class FluxoCompleto(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.admin = Cliente()
        cls.viewer = Cliente()

    # --- ordem alfabética dos testes define o fluxo ---
    def test_01_setup_e_login(self):
        r = self.admin.get("/")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/setup", r.headers["Location"])
        # CSRF obrigatório
        r = self.admin.post("/setup", {"nome": "Ana", "usuario": "ana", "senha": "senha-forte-1",
                                       "confirmar": "senha-forte-1"}, csrf=False)
        self.assertEqual(r.status_code, 400)
        # senha curta
        r = self.admin.post("/setup", {"nome": "Ana Admin", "usuario": "ana", "senha": "123",
                                       "confirmar": "123"})
        self.assertEqual(r.status_code, 400)
        r = self.admin.post("/setup", {"nome": "Ana Admin", "usuario": "ana", "senha": "senha-forte-1",
                                       "confirmar": "senha-forte-1"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.admin.get("/").status_code, 200)
        # setup não pode ser reutilizado
        self.assertEqual(self.admin.get("/setup").status_code, 302)

    def test_02_dashboard_vazio_sem_dados_ficticios(self):
        html = self.admin.get("/").get_data(as_text=True)
        self.assertIn("Nenhuma advertência registrada", html)
        con = sqlite3.connect(os.path.join(TMP, "advertencias.db"))
        self.assertEqual(con.execute("SELECT COUNT(*) FROM pessoas").fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM advertencias").fetchone()[0], 0)
        con.close()

    def test_03_usuarios_e_permissoes(self):
        r = self.admin.post("/usuarios/novo", {"nome": "Vera Viewer", "usuario": "vera",
                                               "papel": "visualizador", "senha": "outra-senha-9"})
        self.assertEqual(r.status_code, 302)
        # usuário duplicado
        r = self.admin.post("/usuarios/novo", {"nome": "X", "usuario": "VERA", "papel": "visualizador",
                                               "senha": "outra-senha-9"})
        self.assertEqual(r.status_code, 400)
        # login do visualizador
        r = self.viewer.post("/login", {"usuario": "vera", "senha": "errada"})
        self.assertEqual(r.status_code, 401)
        r = self.viewer.post("/login", {"usuario": "vera", "senha": "outra-senha-9"})
        self.assertEqual(r.status_code, 302)
        # o visualizador não acessa telas administrativas
        for url in ("/pessoas/nova", "/advertencias/nova", "/usuarios", "/auditoria"):
            self.assertEqual(self.viewer.get(url).status_code, 403, url)

    def test_04_pessoas_crud(self):
        r = self.admin.post("/pessoas/nova", {"nome": "", "funcao": ""})
        self.assertEqual(r.status_code, 400)
        r = self.admin.post("/pessoas/nova", {"nome": "João da Silva Çaña", "funcao": "Operador",
                                              "observacoes": "Turno da manhã"})
        self.assertEqual(r.status_code, 302)
        r = self.admin.post("/pessoas/nova", {"nome": "Maria Souza", "funcao": "Analista", "observacoes": ""})
        self.assertEqual(r.status_code, 302)
        r = self.admin.post("/pessoas/nova", {"nome": "Pedro Lima", "funcao": "Motorista", "observacoes": ""})
        self.assertEqual(r.status_code, 302)
        # busca sem acento e sem diferenciar maiúsculas
        html = self.admin.get("/pessoas?q=joao").get_data(as_text=True)
        self.assertIn("João da Silva Çaña", html)
        self.assertNotIn("Maria Souza", html)
        html = self.admin.get("/pessoas?q=CANA").get_data(as_text=True)
        self.assertIn("João da Silva", html)
        # edição
        r = self.admin.post("/pessoas/2/editar", {"nome": "Maria Souza Reis", "funcao": "Analista Sênior",
                                                  "observacoes": ""})
        self.assertEqual(r.status_code, 302)
        self.assertIn("Maria Souza Reis", self.admin.get("/pessoas/2").get_data(as_text=True))
        # visualizador consegue ver, mas não alterar
        self.assertEqual(self.viewer.get("/pessoas/2").status_code, 200)
        r = self.viewer.post("/pessoas/2/editar", {"nome": "Hack", "funcao": "x"}, token_url="/pessoas/2")
        self.assertEqual(r.status_code, 403)
        r = self.viewer.post("/pessoas/2/excluir", token_url="/pessoas/2")
        self.assertEqual(r.status_code, 403)

    def _adv(self, **extra):
        d = {"pessoa_id": "1", "titulo": "Atraso reiterado", "motivo": "Chegou 40 minutos atrasado.",
             "categoria": "Atraso", "ocorrido_em": "2026-10-10T08:40", "responsavel": "Ana Admin",
             "observacoes": "", "status": "ativa"}
        d.update(extra)
        return d

    def test_05_advertencias_crud_e_validacao(self):
        for ruim in ({"pessoa_id": "999"}, {"titulo": ""}, {"motivo": ""}, {"categoria": "Inventada"},
                     {"ocorrido_em": "ontem"}, {"responsavel": ""}, {"status": "cancelada"}):
            r = self.admin.post("/advertencias/nova", self._adv(**ruim))
            self.assertEqual(r.status_code, 400, ruim)
        r = self.admin.post("/advertencias/nova", self._adv())
        self.assertEqual(r.status_code, 302)
        # várias advertências para a mesma pessoa
        self.admin.post("/advertencias/nova", self._adv(titulo="Falta sem aviso", categoria="Falta",
                                                        ocorrido_em="2026-10-20T09:00",
                                                        motivo="Faltou sem justificar."))
        self.admin.post("/advertencias/nova", self._adv(titulo="Uso indevido de EPI", categoria="Segurança",
                                                        ocorrido_em="2026-11-01T14:30",
                                                        motivo="Sem capacete na área."))
        self.admin.post("/advertencias/nova", self._adv(pessoa_id="2", titulo="Prazo descumprido",
                                                        categoria="Desempenho",
                                                        ocorrido_em="2026-09-15T10:00",
                                                        motivo="Entrega fora do prazo."))
        con = sqlite3.connect(os.path.join(TMP, "advertencias.db"))
        self.assertEqual(con.execute("SELECT COUNT(*) FROM advertencias WHERE pessoa_id = 1").fetchone()[0], 3)
        con.close()
        # perfil: ordem do mais recente para o mais antigo
        html = self.admin.get("/pessoas/1").get_data(as_text=True)
        i1, i2, i3 = (html.index(t) for t in ("Uso indevido de EPI", "Falta sem aviso", "Atraso reiterado"))
        self.assertTrue(i1 < i2 < i3)
        # detalhe e visualizador
        self.assertEqual(self.viewer.get("/advertencias/1").status_code, 200)
        self.assertEqual(self.viewer.get("/advertencias/1/editar").status_code, 403)
        r = self.viewer.post("/advertencias/1/cancelar", {"motivo_cancelamento": "x"}, token_url="/advertencias/1")
        self.assertEqual(r.status_code, 403)
        # edição + auditoria
        r = self.admin.post("/advertencias/1/editar", self._adv(titulo="Atraso reiterado (3ª vez)",
                                                                status="revisada"))
        self.assertEqual(r.status_code, 302)
        html = self.admin.get("/advertencias/1").get_data(as_text=True)
        self.assertIn("Atraso reiterado (3ª vez)", html)
        self.assertIn("Revisada", html)
        self.assertIn("Título", html)  # histórico de alterações

    def test_06_filtros(self):
        def n(qs):
            html = self.admin.get("/advertencias?" + qs).get_data(as_text=True)
            return html.count('/advertencias/') - html.count('/advertencias/nova') \
                - html.count('/advertencias/exportar') - html.count('/advertencias?')
        todas = self.admin.get("/advertencias").get_data(as_text=True)
        self.assertIn("4 resultados", todas)
        self.assertIn("1 resultado ", self.admin.get("/advertencias?q=capacete").get_data(as_text=True))
        self.assertIn("1 resultado ", self.admin.get("/advertencias?q=AREA").get_data(as_text=True))
        self.assertIn("1 resultado ", self.admin.get("/advertencias?q=prazo").get_data(as_text=True))
        self.assertIn("3 resultados", self.admin.get("/advertencias?pessoa=1").get_data(as_text=True))
        self.assertIn("1 resultado ", self.admin.get("/advertencias?categoria=Falta").get_data(as_text=True))
        self.assertIn("1 resultado ", self.admin.get("/advertencias?status=revisada").get_data(as_text=True))
        self.assertIn("3 resultados", self.admin.get("/advertencias?status=ativa").get_data(as_text=True))
        self.assertIn("2 resultados", self.admin.get("/advertencias?de=2026-10-15&ate=2026-11-30").get_data(as_text=True))
        self.assertIn("1 resultado ", self.admin.get("/advertencias?de=2026-10-01&ate=2026-10-15").get_data(as_text=True))
        self.assertIn("Nenhuma advertência corresponde",
                      self.admin.get("/advertencias?q=inexistente").get_data(as_text=True))
        # entradas maliciosas / inválidas não quebram
        for qs in ("q=%25%27%22", "de=lixo&ate=9999-99-99", "pessoa=abc", "page=-5", "page=zzz", "status=x"):
            self.assertEqual(self.admin.get("/advertencias?" + qs).status_code, 200, qs)
        # CSV
        r = self.admin.get("/advertencias/exportar.csv?pessoa=1")
        self.assertEqual(r.status_code, 200)
        self.assertIn("text/csv", r.headers["Content-Type"])
        self.assertIn("Uso indevido de EPI", r.get_data(as_text=True))
        self.assertNotIn("Prazo descumprido", r.get_data(as_text=True))

    def test_07_cancelar_e_reativar_mantem_historico(self):
        # sem motivo não cancela
        r = self.admin.post("/advertencias/2/cancelar", {"motivo_cancelamento": "  "},
                            token_url="/advertencias/2", follow=True)
        self.assertIn("Informe o motivo do cancelamento", r.get_data(as_text=True))
        r = self.admin.post("/advertencias/2/cancelar", {"motivo_cancelamento": "Aplicada por engano."},
                            token_url="/advertencias/2")
        self.assertEqual(r.status_code, 302)
        html = self.admin.get("/advertencias/2").get_data(as_text=True)
        self.assertIn("Advertência cancelada", html)
        self.assertIn("Aplicada por engano.", html)
        # registro continua no perfil e na lista
        self.assertIn("Falta sem aviso", self.admin.get("/pessoas/1").get_data(as_text=True))
        self.assertIn("Cancelada", self.admin.get("/advertencias?status=cancelada").get_data(as_text=True))
        # cancelada não pode ser editada
        self.assertEqual(self.admin.get("/advertencias/2/editar").status_code, 302)
        # dashboard não conta cancelada no ranking
        dash = self.admin.get("/").get_data(as_text=True)
        self.assertIn("1 cancelada(s)", dash)
        # reativar
        r = self.admin.post("/advertencias/2/reativar", token_url="/advertencias/2")
        self.assertEqual(r.status_code, 302)
        self.assertIn("Ativa", self.admin.get("/advertencias/2").get_data(as_text=True))
        aud = self.admin.get("/auditoria?acao=cancelou").get_data(as_text=True)
        self.assertIn("cancelada", aud)
        self.assertIn("Aplicada por engano.", aud)

    def test_08_dashboard_com_dados(self):
        html = self.admin.get("/").get_data(as_text=True)
        self.assertIn("João da Silva Çaña", html)  # mais advertências
        self.assertIn("Uso indevido de EPI", html)  # última adicionada aparece
        # visualizador também vê, sem botão de criar
        v = self.viewer.get("/").get_data(as_text=True)
        self.assertNotIn("Nova advertência", v)

    def test_09_auditoria(self):
        html = self.admin.get("/auditoria").get_data(as_text=True)
        for trecho in ("registrada para", "editada", "cadastrada", "criado"):
            self.assertIn(trecho, html)
        self.assertEqual(self.admin.get("/auditoria?q=capacete&entidade=advertencia").status_code, 200)

    def test_10_excluir_pessoa_audita_snapshot(self):
        r = self.admin.post("/pessoas/3/excluir", token_url="/pessoas/3")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.admin.get("/pessoas/3").status_code, 404)
        r = self.admin.post("/pessoas/2/excluir", token_url="/pessoas/2")
        self.assertEqual(r.status_code, 302)
        con = sqlite3.connect(os.path.join(TMP, "advertencias.db"))
        self.assertEqual(con.execute("SELECT COUNT(*) FROM advertencias WHERE pessoa_id = 2").fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM historico WHERE acao = 'excluiu'").fetchone()[0], 2)
        con.close()
        aud = self.admin.get("/auditoria?acao=excluiu").get_data(as_text=True)
        self.assertIn("Prazo descumprido", aud)

    def test_11_seguranca(self):
        anon = Cliente()
        for url in ("/", "/pessoas", "/advertencias", "/usuarios", "/auditoria", "/pessoas/1"):
            r = anon.get(url)
            self.assertEqual(r.status_code, 302, url)
            self.assertIn("/login", r.headers["Location"])
        # POST sem token é rejeitado
        r = self.admin.post("/pessoas/nova", {"nome": "X", "funcao": "Y"}, csrf=False)
        self.assertEqual(r.status_code, 400)
        # redirecionamento aberto bloqueado
        outro = Cliente()
        r = outro.post("/login?next=//evil.com", {"usuario": "ana", "senha": "senha-forte-1"})
        self.assertEqual(r.status_code, 302)
        self.assertNotIn("evil.com", r.headers["Location"])
        # cabeçalhos
        r = self.admin.get("/")
        self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        # XSS escapado
        self.admin.post("/pessoas/nova", {"nome": "<script>alert(1)</script>", "funcao": "x", "observacoes": ""})
        html = self.admin.get("/pessoas").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)
        # injeção SQL na busca
        self.assertEqual(self.admin.get("/pessoas?q=' OR 1=1 --").status_code, 200)

    def test_12_bloqueio_apos_tentativas(self):
        c = Cliente()
        for _ in range(sistema.MAX_TENTATIVAS):
            r = c.post("/login", {"usuario": "vera", "senha": "errada"})
            self.assertEqual(r.status_code, 401)
        r = c.post("/login", {"usuario": "vera", "senha": "outra-senha-9"})
        self.assertEqual(r.status_code, 401)
        self.assertIn("Muitas tentativas", r.get_data(as_text=True))

    def test_13_gestao_de_usuarios(self):
        # não pode desativar/rebaixar o único admin
        r = self.admin.post("/usuarios/1/editar", {"nome": "Ana Admin", "papel": "visualizador", "ativo": "1"})
        self.assertEqual(r.status_code, 400)
        r = self.admin.post("/usuarios/1/editar", {"nome": "Ana Admin", "papel": "administrador"})
        self.assertEqual(r.status_code, 400)
        # desativar usuário impede acesso imediato
        r = self.admin.post("/usuarios/2/editar", {"nome": "Vera Viewer", "papel": "visualizador"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.viewer.get("/pessoas").status_code, 302)

    def test_14_troca_de_senha(self):
        r = self.admin.post("/conta/senha", {"atual": "errada", "nova": "novaSenha123", "confirmar": "novaSenha123"})
        self.assertEqual(r.status_code, 400)
        r = self.admin.post("/conta/senha", {"atual": "senha-forte-1", "nova": "novaSenha123",
                                             "confirmar": "novaSenha123"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.admin.get("/").status_code, 200)  # sessão segue válida
        novo = Cliente()
        r = novo.post("/login", {"usuario": "ana", "senha": "novaSenha123"})
        self.assertEqual(r.status_code, 302)

    def test_15_persistencia(self):
        con = sqlite3.connect(os.path.join(TMP, "advertencias.db"))
        self.assertGreaterEqual(con.execute("SELECT COUNT(*) FROM advertencias").fetchone()[0], 3)
        self.assertGreaterEqual(con.execute("SELECT COUNT(*) FROM historico").fetchone()[0], 8)
        con.close()

    def test_16_logout(self):
        c = Cliente()
        c.post("/login", {"usuario": "ana", "senha": "novaSenha123"})
        self.assertEqual(c.get("/").status_code, 200)
        c.post("/logout", token_url="/")
        self.assertEqual(c.get("/").status_code, 302)

    def test_17_paginas_de_erro(self):
        self.assertEqual(self.admin.get("/pessoas/9999").status_code, 404)
        self.assertEqual(self.admin.get("/advertencias/9999").status_code, 404)
        self.assertEqual(self.admin.get("/nao-existe").status_code, 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
