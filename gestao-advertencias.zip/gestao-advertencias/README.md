# Gerenciamento de Advertências

Sistema web (Flask + SQLite) para cadastrar pessoas, registrar advertências e consultar o histórico.

## Como executar

```bash
python -m venv venv
# Windows: venv\Scripts\activate    |  Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Abra http://127.0.0.1:5000. No **primeiro acesso** o sistema pede para criar a conta do
administrador (não existe usuário/senha padrão). Nenhum dado fictício é criado.

## Níveis de acesso
- **Administrador**: cadastra/edita/exclui pessoas, registra/edita/cancela/reativa advertências, gerencia usuários e vê a auditoria.
- **Visualizador**: apenas consulta pessoas e advertências (e exporta CSV).

Usuários são criados em *Administração → Usuários*.

## Dados
Tudo fica em `data/advertencias.db` (SQLite) e persiste ao fechar/atualizar a página.
Para backup, copie a pasta `data/` (inclui `secret.key`, usada nas sessões).

## Esqueceu a senha?
```bash
flask --app app redefinir-senha NOME_DO_USUARIO
```

## Configuração (variáveis de ambiente)
`HOST`, `PORT`, `ADVERT_DATA_DIR`, `APP_TZ` (padrão America/Sao_Paulo), `SECRET_KEY`,
`ADVERT_HTTPS=1` (cookie seguro, use atrás de HTTPS).
As categorias ficam na lista `CATEGORIAS` no início de `app.py`.
Para uso em rede/produção prefira um servidor WSGI: `pip install waitress` e `waitress-serve --port=5000 app:app`.

## Testes
```bash
python -m unittest discover -s tests
```
